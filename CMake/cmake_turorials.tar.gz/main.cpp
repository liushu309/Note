#include <iostream>
#include "mymath/myadd.h"
#include "mymath2/mymul.h"

int main(int argc, char **argv){
    int a, b;
    std::cin >> a >> b;
    std::cout << "the a is " << a << std::endl << "the b is " << b << std::endl;
    // std::cout << "the arguments is " << argv[1] << " " << argv[2] << std::endl;
    int add_result = add_func(a, b);
    std::cout << "the add result is " << add_result << std::endl;
    int mul_result = mul_func(a, b);
    std::cout << "the mul result is " << mul_result << std::endl;
    return 0;    
}
