## How to build the project
just cd build and cmake .., make, install