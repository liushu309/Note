#ifndef __MYMUL__
#define __MYMUL__

int mul_func(int a, int b);

#endif