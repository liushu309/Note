#include "mymul.h"

int mul_func(int a, int b){
    return a*b;
}