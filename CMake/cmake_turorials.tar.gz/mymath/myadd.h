#ifndef __MYMATH__
#define __MYMATH__
#include "myadd.h"

int add_func(int a, int b);

#endif