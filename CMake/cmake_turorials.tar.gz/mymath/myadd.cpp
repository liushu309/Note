#include "myadd.h"

int add_func(int a, int b){
    return a + b;
}