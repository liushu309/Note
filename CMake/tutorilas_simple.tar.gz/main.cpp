#include <opencv2/opencv.hpp>
#include <iostream>
#include "mymath/add_func.h"

int main(int argc, char **argv){
    int a, b;
    std::cin >> a >> b;
    int sum;
    sum = add_func(a, b);
    std::cout << "the sum is " << sum << std::endl;

    cv::Mat test = cv::imread("../1.png", 1);
    cv::imshow("show", test);
    cv::waitKey(0);
    
    return 0;
}