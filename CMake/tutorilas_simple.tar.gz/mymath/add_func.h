#ifndef __ADD_FUNC__
#define __ADD_FUNC__

int add_func(int a, int b);

#endif