#include "add_func.h"

int add_func(int a, int b){
    return a + b;
}